package com.example.demo.config;

import com.example.demo.Repository.TokenRepository;
import com.example.demo.entity.Token;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;
    private final TokenRepository tokenRepository;
    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain) throws ServletException, IOException {

        System.out.println("starting JwtAuthenticationFilter: " + request + "\n"
                + request.getHeader("Authorization"));
        if (request.getServletPath().contains("/api/v1/auth")) {
            filterChain.doFilter(request, response);
            return;
        }
        if (request.getServletPath().contains("/h2-console")) {
            filterChain.doFilter(request, response);
            return;
        }

        //
        final String authHeader = request.getHeader("Authorization");
        System.out.println("auth header: " + authHeader);

        if (authHeader == null ||!authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        } else {
            System.out.println("valid auth header");
        }

        final String jwt = authHeader.substring(7);
        System.out.println("jwt: " + jwt);
        final String userEmail = jwtService.extractUsername(jwt);
        System.out.println("userEmail: " + userEmail);

        if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            System.out.println("\ninside if block of JwtAuthenticationFilter\n");
            UserDetails userDetails = userDetailsService.loadUserByUsername(userEmail);
            System.out.println("userDetails: " + userDetails);

            Optional<Token> t = tokenRepository.findByToken(jwt);
            t.ifPresent(System.out::println);
            boolean b1 = false;
            boolean b2 = false;
            if(t.isPresent()) {
                Token t1 = t.get();
                System.out.println("retrieved token: " + t1);
                b1 = !t1.revoked && !t1.expired;
                System.out.println("\n b1: " + b1);
            } else {
                System.out.println("no token");
            }
            b2 = jwtService.isTokenValid(jwt, userDetails);
            System.out.println("\n b2: " + b2);
//            boolean isTokenValid = tokenRepository.findByToken(jwt)
//                    .map(t -> !t.isExpired() && !t.isRevoked())
//                    .orElse(false);
            //System.out.println("isTokenValid: " + isTokenValid);

            //if (jwtService.isTokenValid(jwt, userDetails) && isTokenValid) {
            if (b1 && b2) {
                System.out.println("\n token is valid");
                UsernamePasswordAuthenticationToken authToken =
                        new UsernamePasswordAuthenticationToken(userDetails,
                                null,
                                userDetails.getAuthorities());
                authToken.setDetails(
                        new WebAuthenticationDetailsSource().buildDetails(request)
                );
                SecurityContextHolder.getContext().setAuthentication(authToken);
            } else {
                System.out.println("token is not valid");
            }
        } else {
            System.out.println("\ninside else block of JwtAuthenticationFilter");
        }
        filterChain.doFilter(request, response);
    }
}
