package com.example.demo.controller;


//import org.springframework.security.access.prepost.PreAuthorize;
import com.example.demo.Model.UserDto;
import com.example.demo.Repository.MemberRepository;
import com.example.demo.entity.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/demo-controller")
public class MyController {

    @Autowired
    private MemberRepository userRepository;

    @GetMapping("/hello")
    public ResponseEntity<String> sayHello() {
        return ResponseEntity.ok("Hello from secured endpoint");
    }

    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome!";
    }
//
//    @GetMapping("/testUser")
//    public UserDto testUser() {
//
//        //create a hardcoded user
//        Member u = userRepository.save(createTestUser());
//        return UserDto.builder().id(u.getId()).firstName(u.getFirstName()).lastName(u.getLastName()).build();
//    }
//
//    private Member createTestUser() {
//        return Member.builder().firstName("Kunal").lastName("Dutta").build();
//    }

//
//    @GetMapping("/user/userProfile")
//    //@PreAuthorize("hasAuthority('ROLE_USER')")
//    public String userProfile() {
//        return "Welcome to User Profile";
//    }
//
//    @GetMapping("/admin/adminProfile")
//    //@PreAuthorize("hasAuthority('ROLE_ADMIN')")
//    public String adminProfile() {
//        return "Welcome to Admin Profile";
//    }
}
